package com.gaan.liver.ui.profile;

public class ProfileViewModel {
}
