package com.gaan.liver.ui.auth.login;

import android.arch.lifecycle.ViewModel;

public class LoginViewModel extends ViewModel {
    
}