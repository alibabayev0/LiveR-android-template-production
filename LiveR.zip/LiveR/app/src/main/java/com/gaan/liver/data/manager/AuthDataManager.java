package com.gaan.liver.data.manager;

import android.content.Context;

public class AuthDataManager {
    Context mContext;

    public AuthDataManager(Context context) {
        mContext = context;
    }



}
