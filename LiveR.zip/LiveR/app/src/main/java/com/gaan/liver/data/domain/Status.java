package com.gaan.liver.data.domain;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING,
}
