package com.gaan.liver.ui.auth.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.gaan.liver.R;
import com.gaan.liver.base.BaseActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auth_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, LoginFragment.newInstance())
                    .commitNow();
        }
    }
}