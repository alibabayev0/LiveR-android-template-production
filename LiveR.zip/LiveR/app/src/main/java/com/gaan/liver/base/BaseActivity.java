package com.gaan.liver.base;


import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.LayoutRes;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.gaan.liver.ui.auth.login.LoginActivity;
import com.orhanobut.hawk.Hawk;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import javax.inject.Inject;

public abstract class BaseActivity<T extends ViewDataBinding, V extends ViewModel> extends AppCompatActivity {

    private T mViewDataBinding;

    protected V mViewModel;

//
//    protected Class<V> mViewModelClass;
//
//    public void BaseActivity(Class<V> mViewModelClass){
//        this.mViewModelClass = mViewModelClass;
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Hawk.init(this).build();
        performViewModel();
        performDataBinding();
    }

    public abstract
    @LayoutRes
    int getLayoutId();

    /**
     * Override for set binding variable
     *
     * @return variable id
     */
        public abstract int getBindingVariable();


    /**
     *
     * DataBinding setter
     */
    public T getViewDataBinding() {
        return mViewDataBinding;
    }


    /**
     *
     * Hiding Keyboard in every view
     */
    public void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        }
    }

    /**
     *
     * @param clz
     * @param bundle
     * Function for starting clz activity with bundle
     */

    public void startActivity(Class<?> clz, Bundle bundle) {
        Intent intent = new Intent(this, clz);
        if (bundle != null) {
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }

    public void openActivityOnTokenExpire() {
//        startActivity(LoginActivity.newIntent(this));
        finish();
    }


//    /**
//     * Network Status checker by Utils
//     * @return
//     */
//    public boolean isNetworkConnected() {
//        return NetworkUtils.isNetworkConnected(getApplicationContext());
//    }


    private void performDataBinding() {
        mViewDataBinding = DataBindingUtil.setContentView(this, getLayoutId());
        mViewDataBinding.setVariable(getBindingVariable(), mViewModel);
        mViewDataBinding.setLifecycleOwner(this);
        mViewDataBinding.executePendingBindings();
    }


    private void performViewModel() {
        mViewModel = null;
        Class modelClass;
        Type type = getClass().getGenericSuperclass();
        if (type instanceof ParameterizedType) {
            modelClass = (Class) ((ParameterizedType) type).getActualTypeArguments()[1];
        } else {
            //如果没有指定泛型参数，则默认使用BaseViewModel
            modelClass = BaseViewModel.class;
        }
        mViewModel = (V) createViewModel(this, modelClass);
    }


    public <T extends ViewModel> T createViewModel(FragmentActivity activity, Class<T> cls) {
        return ViewModelProviders.of(activity).get(cls);
    }
}