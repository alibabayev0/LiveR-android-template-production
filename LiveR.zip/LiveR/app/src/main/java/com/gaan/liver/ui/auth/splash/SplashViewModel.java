package com.gaan.liver.ui.auth.splash;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.gaan.liver.base.BaseViewModel;
import com.gaan.liver.util.rx.SchedulerProvider;

public class SplashViewModel extends BaseViewModel<SplashNavigator> {


    public SplashViewModel(SchedulerProvider schedulerProvider) {
        super(schedulerProvider);
    }

    public void startCheckStatusUser(){
    }

}
