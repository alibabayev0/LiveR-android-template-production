package com.gaan.liver.ui.auth.register;

public class RegisterViewModel {
}
