package com.gaan.liver.ui.auth.splash;

public interface SplashNavigator {
    void openLoginActivity();

    void openLoginLikeActivity();

    void openArActivity();
}
