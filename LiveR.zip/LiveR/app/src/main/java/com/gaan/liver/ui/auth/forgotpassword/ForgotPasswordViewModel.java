package com.gaan.liver.ui.auth.forgotpassword;

public class ForgotPasswordViewModel {
}
