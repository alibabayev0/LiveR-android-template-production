package com.gaan.liver.ui.ar;

import com.gaan.liver.base.BaseViewModel;
import com.gaan.liver.util.rx.SchedulerProvider;

public class ArViewModel extends BaseViewModel<ArNavigator> {

    public ArViewModel(SchedulerProvider schedulerProvider) {
        super(schedulerProvider);
    }


}
