package com.gaan.liver.ui.settings;

public class SettingsViewModel {
}
