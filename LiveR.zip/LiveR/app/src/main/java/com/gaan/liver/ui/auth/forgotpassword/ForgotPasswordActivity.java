package com.gaan.liver.ui.auth.forgotpassword;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.gaan.liver.R;

public class ForgotPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.gaan.liver.R.layout.activity_forgot_password);
    }
}