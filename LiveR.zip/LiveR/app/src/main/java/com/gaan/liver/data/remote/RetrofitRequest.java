package com.gaan.liver.data.remote;

import com.gaan.liver.data.local.AppPreferencesHelper;
import com.gaan.liver.data.manager.AuthDataManager;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitRequest {
    private static Retrofit retrofitDefault = null;
    private static Retrofit retrofitHeader = null;

    static OkHttpClient  defaultHttpClient = new OkHttpClient.Builder()
            .addInterceptor(new Interceptor() {
                @Override
                public Response intercept(Interceptor.Chain chain) throws IOException {
                    //getAccessToken is your own accessToken(retrieve it by saving in shared preference or any other option )
                    Request authorisedRequest = chain.request().newBuilder()
                            .build();
                    return chain.proceed(authorisedRequest);
                }}).build();

    static OkHttpClient  headerHttpClient = new OkHttpClient.Builder()
            .addInterceptor(new Interceptor() {
                @Override
                public Response intercept(Interceptor.Chain chain) throws IOException {
                    //getAccessToken is your own accessToken(retrieve it by saving in shared preference or any other option )
                    AppPreferencesHelper appPreferencesHelper = new AppPreferencesHelper();
                    Request authorisedRequest = chain.request().newBuilder()
                            .addHeader("auth_token",  appPreferencesHelper.getUserAccessToken())
                            .addHeader("api_key", ApiConstants.API_KEY)
                            .addHeader("user_id", appPreferencesHelper.getUserAccessToken())
                            .build();
                    return chain.proceed(authorisedRequest);
                }}).build();


    public static Retrofit getClientForAuth(){
        if(retrofitDefault == null)
            retrofitDefault = new Retrofit.Builder()
                    .baseUrl(ApiConstants.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(defaultHttpClient)
                    .build();
        return retrofitDefault;
    }

    public static Retrofit getClient(){
        if(retrofitHeader == null)
            retrofitHeader = new Retrofit.Builder()
                    .baseUrl(ApiConstants.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(headerHttpClient)
                    .build();
        return retrofitHeader;
    }
}
