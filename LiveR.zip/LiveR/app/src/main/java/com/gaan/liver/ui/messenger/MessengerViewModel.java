package com.gaan.liver.ui.messenger;

public class MessengerViewModel {
}
