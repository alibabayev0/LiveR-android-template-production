package com.gaan.liver.data.remote;


import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface IAuthApi {

    @POST(ApiConstants.API_URL)
    Single<String> postFacebookApiCall(Body FacebookLoginRequest);

    Single<String> postGoogleApiCall(Body GoogleLoginRequest);

    Single<String> postLoginApiCall(Body LoginRequest);

    ApiHeader getApiHeader();
}
