package com.gaan.liver.ui.discover;

public class DiscoverViewModel {
}
