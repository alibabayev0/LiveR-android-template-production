package com.gaan.liver.ui.ar;

public interface ArNavigator {
}
